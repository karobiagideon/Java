This is a simple JavaFXML project for signup and login which animates the login and signup cards.I've ussed conrolsfx and jfoenix libraries in the project. I've Included them in the project folder.
Happy Coding :)
credits to Benny Coder (Youtube) https://www.youtube.com/watch?v=jtdTHAQSb6c Like and Subscribe.

